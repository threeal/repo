`Makefile` is intended to be used under nRF IoT SDK (see
../../../../README.md); `Makefile.docker` is intended to be used under Cesanta
repository.
