Please download the [nRF51 IoT SDK](http://www.nordicsemi.com/eng/Products/Bluetooth-low-energy/nRF51-IoT-SDK)
and unpack it into this directory, so that it contains `components`, `external`, etc.
